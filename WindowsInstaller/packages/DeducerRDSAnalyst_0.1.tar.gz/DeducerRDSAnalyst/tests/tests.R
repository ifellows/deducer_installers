library(testthat)
options(DeducerNoGUI=TRUE)
library(DeducerRDSAnalyst)

test_package("DeducerRDSAnalyst")

