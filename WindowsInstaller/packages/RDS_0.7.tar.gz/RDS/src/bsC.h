#ifndef BSC_H
#define BSC_H

void bsC (
            int *nbyclass,
            int *classesboth,
            int *nrefs,
            double *props2,
            double *tempties,
            double *pis, 
            double *est,
            int *numsamp,
            int *offby,
            int *K, 
            int *nc, 
            int *g, 
            int *N, 
            int *n, 
            int *n0
		 );

#endif /* BSC_H */
