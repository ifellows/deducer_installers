

library(testthat)
library(RDS)

test_package("RDS")
